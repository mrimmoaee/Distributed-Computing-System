
package Email;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Socket_Server {
    
    public static void main(String[] args) throws AddressException, MessagingException {  
        
        System.out.println("The Socket Server is ready");  
        try {  
            //1.Create a Socket and binding a port 
            ServerSocket serverSocket=new ServerSocket(8800);
            
            //2.using accept() to stops waiting for listening and gets a new connection
            Socket socket = serverSocket.accept();  
            
            //3.get InputStream 
            InputStream is = socket.getInputStream();  
            BufferedReader br=new BufferedReader(new InputStreamReader(is));  
            
            // Get OutputStream  
            OutputStream os = socket.getOutputStream();  
            PrintWriter pw=new PrintWriter(os);  
            
            //4.Read the infomation of client  
            String mail=null;
            String name = null;
            
            while(!((mail=br.readLine())==null)){  
                //System.out.println("I am a server, The feedback of client is："+info);
                //System.out.println(info);
                System.out.println(mail);
                //---------------------------Sent E-mail to Student---------------------------
                String host ="smtp.gmail.com" ;
                String user = "shomegr123@gmail.com";
                String pass = "Shome1010";
                String to = mail;
                String from = "shomegr123@gmail.com";
                String subject = "APU Library";
                String messageText = "Hello, "+ name +"! This is a confirmation email that you have registered the account for library system.";
                boolean sessionDebug = false;

                Properties props = System.getProperties();

                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.host", host);
                props.put("mail.smtp.port", "888");
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.required", "true");

                java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
                Session mailSession = Session.getDefaultInstance(props, null);
                mailSession.setDebug(sessionDebug);
                Message msg = new MimeMessage(mailSession);
                msg.setFrom(new InternetAddress(from));
                InternetAddress[] address = {new InternetAddress(to)};
                msg.setRecipients(Message.RecipientType.TO, address);
                msg.setSubject(subject); msg.setSentDate(new Date());
                msg.setText(messageText);

                Transport transport=mailSession.getTransport("smtp");
                transport.connect(host, user, pass);
                transport.sendMessage(msg, msg.getAllRecipients());
                transport.close();
                System.out.println("message send successfully");
                //-----------------------------------------------------------------------------
            }                 
            // Make a reply for client 
            String reply="Thanks for your Feedback !";  
            pw.write(reply);  
            pw.flush();  
            
            //5.Close resource  
            pw.close();  
            os.close();  
            br.close();  
            is.close();  
            socket.close();  
            serverSocket.close(); 
            
            
        } catch (IOException e) {  
            e.printStackTrace();  
            
        }               
    }  
    
    
}
