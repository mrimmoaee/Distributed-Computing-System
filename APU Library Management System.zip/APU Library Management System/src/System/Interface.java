
package System;

import StudentClass.Book;
import StudentClass.Student;
import java.awt.List;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public interface Interface extends Remote {
    
    
    // Creating Remote interface for application 
    public boolean getLogin (String id, String pass) throws RemoteException; 
    public void getRegister(String id, String pass, String name, String mail, String dob, String intake) throws RemoteException;
    public ArrayList<Book> bookList() throws RemoteException;
  

 
}
