
package System;

import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


//Multithreading apply to the server
public class Server extends Thread {
    
    @Override
    public void run () {
        try {
            //Server create registry for requesting service from client
            Registry reg = LocateRegistry.createRegistry(1054);
            Interface imp = new SystemImplement();
            //Implements remote interface equal to 'Server' for client to lookup
            reg.rebind("Server", (Remote) imp);
            System.out.println("Server is up!");

        } catch (RemoteException ex) {
            ex.printStackTrace();
        } 
    }
    
    public static void main(String[] args) {
                      		     
        Server s = new Server();
        s.start();
       
    }
      
}
