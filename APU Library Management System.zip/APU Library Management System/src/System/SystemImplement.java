
package System;

import StudentClass.Book;
import StudentClass.Student;
import java.awt.List;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class SystemImplement extends UnicastRemoteObject implements Interface{
    
    
    Statement st;
    Connection con;
     // Implemetation of remote interface Interface
    public SystemImplement() throws RemoteException {
        super();
    }

    //methods getRegister that passes user and pass as String
    @Override
     public void getRegister(String id, String pass, String name, String mail, String dob, String intake) throws RemoteException {
        
          
       try {
            //connection established
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/Apu Library Management System 2","Shamee","1234");
            System.out.println("connection Established");
            //Insert student detail information
            PreparedStatement stmt = con.prepareStatement("insert into STUDENT values(?,?,?,?,?,?)");
            stmt.setString(1, id);
            stmt.setString(2, pass);
            stmt.setString(3, name);
            stmt.setString(4, mail);
            stmt.setString(5, dob);
            stmt.setString(6, intake);
            
            stmt.executeUpdate();
            con.commit();
            con.close(); // close connection
           
       }
       
       catch(Exception e){
           System.out.println(""+e);
       }                
      
    }
 
    @Override
    //login function
    public boolean getLogin(String id, String pass) throws RemoteException {
        boolean found = false;
        try {
            //To check user and pass is not empty
            if ((id != null && !id.isEmpty()) && (pass != null && !pass.isEmpty())) {
                return found = true;
            } else {
                return found = false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return found;
    }


    
    @Override
    public ArrayList<Book> bookList() throws RemoteException {
        
        ArrayList<Book> bookList = new ArrayList<>();
        
        try{
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/Apu Library Management System 2","Shamee","1234");
            System.out.println("connection Established");
            String query1= "SELECT * FROM SHAMEE.BOOK";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query1);
            Book book;
            while(rs.next()){
                book= new Book(rs.getString("book_id"), rs.getString("bookname"), rs.getString("author"),rs.getString("category"),rs.getString("course"),rs.getString("available"));
                bookList.add(book);
            }
                       
        }
        
        catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        return bookList;
    }

    
    
 
}
