
package StudentClass;

//serialization the value of book detail
public class Book implements java.io.Serializable {
    
    public String book_id;
    public String book_name;
    public String author;
    public String category;
    public String course;
    public String available;
   
    //constructor of the class book
    public Book (String id, String name, String author, String category, String course, String available){
        this.book_id = id;
        this.book_name = name;
        this.author= author;
        this.category= category; 
        this.course= course;  
        this.available= available;
    }
    
    public String getid(){
        return book_id;
    }
    
     public String getname(){
        return book_name;
    }
    
    public String getauthor(){
        return author;
    }
    
    
    public String getcategory(){
        return category;
    }
    
    public String getcourse(){
        return course;
    }
    
    
    
    public String getavailable(){
        return available;
    }
    
    

    
}
