
package apu.library.management.system;

public class APULibraryManagementSystem {

  
    public static void main(String[] args) {
        welc mf = new welc();
        mf.setVisible(true);
    }
    
}
