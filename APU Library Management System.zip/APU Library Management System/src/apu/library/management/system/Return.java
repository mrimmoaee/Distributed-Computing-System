
package apu.library.management.system;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Return extends javax.swing.JFrame {
    
    //global variables
    Connection con;
    Statement stmt;
    ResultSet rs;
    String query;
    Date date=new Date();
    SimpleDateFormat format=new SimpleDateFormat("dd-MM-yyyy");
    String  checkAvailability,Name,Mail,Intake;

    public Return() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        studentID = new javax.swing.JTextField();
        studentName = new javax.swing.JTextField();
        BookID = new javax.swing.JTextField();
        BookName = new javax.swing.JTextField();
        IssueDate = new javax.swing.JTextField();
        ReturnDate = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setForeground(new java.awt.Color(0, 153, 153));
        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Student Id");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(120, 130, 65, 17);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Student Name");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(100, 160, 88, 17);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Book Id");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(140, 190, 47, 17);

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Book name");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(120, 220, 69, 17);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Issued On");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(130, 250, 70, 17);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Return Date");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(110, 280, 75, 17);

        studentID.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        studentID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentIDActionPerformed(evt);
            }
        });
        studentID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                studentIDKeyReleased(evt);
            }
        });
        jPanel1.add(studentID);
        studentID.setBounds(200, 130, 210, 23);

        studentName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        studentName.setEnabled(false);
        jPanel1.add(studentName);
        studentName.setBounds(200, 160, 210, 23);

        BookID.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        BookID.setEnabled(false);
        jPanel1.add(BookID);
        BookID.setBounds(200, 190, 210, 23);

        BookName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        BookName.setEnabled(false);
        jPanel1.add(BookName);
        BookName.setBounds(200, 220, 210, 23);

        IssueDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        IssueDate.setEnabled(false);
        jPanel1.add(IssueDate);
        IssueDate.setBounds(200, 250, 210, 23);

        ReturnDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ReturnDate.setEnabled(false);
        jPanel1.add(ReturnDate);
        ReturnDate.setBounds(200, 280, 210, 23);

        jButton2.setBackground(new java.awt.Color(204, 204, 204));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(330, 340, 73, 25);

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Return");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(180, 340, 75, 25);

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Book Returing information");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(170, 60, 260, 50);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("APU Library Management System");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(110, 20, 410, 40);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       this.setVisible(false);
        main mf;
        try {
            mf = new main();
            mf.setVisible(true);
        } catch (RemoteException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NotBoundException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        }
      
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try
        {
            connect();
            query="select * from issue where Student_ID='"+studentID.getText()+"'";
            rs=stmt.executeQuery(query);

            if(rs.next())
            {
                query="insert into SHAMEE.RETURNDETAIL  values('"+studentID.getText()+"','";
                query+=studentName.getText()+"','"+BookID.getText()+"','"+BookName.getText()+"','"+IssueDate.getText()+"','"+ReturnDate.getText()+"')";
                stmt.executeUpdate(query);
                query="Delete FROM SHAMEE.ISSUE where STUDENT_ID='" + studentID.getText() + "'";
                stmt.executeUpdate(query);
                query="Update BOOK set Available='YES' where Book_ID='" + BookID.getText() + "'";
                stmt.executeUpdate(query);
                disconnect();
                JOptionPane.showMessageDialog(this,"Book Return Successfully");
                BookName.setText("");
                studentID.setText("");
                studentName.setText("");
                BookID.setText("");
                IssueDate.setText("");
            }
            else
            {
                JOptionPane.showMessageDialog(this,"No book is issued on this id currently");
            }
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(this,e);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void studentIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentIDActionPerformed

    private void studentIDKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_studentIDKeyReleased
        try
        {
            connect();
            query="select * FROM SHAMEE.ISSUE where STUDENT_ID = '" + studentID.getText() + "'";
            rs=stmt.executeQuery(query);
            int i=0;
            while(rs.next())
            {
                i++;
                studentName.setText(rs.getString("Student_Name"));
                BookID.setText(rs.getString("BookId"));
                BookName.setText(rs.getString("BookName"));
                IssueDate.setText(rs.getString("IssueDate"));
            }
            disconnect();
            if(i==0)
            {
                studentName.setText("");
                BookID.setText("");
                BookName.setText("");
                IssueDate.setText("");
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        ReturnDate.setText(format.format(date));
    }//GEN-LAST:event_studentIDKeyReleased

  
    //connection to the database
    public void connect()
    {
        try
        {  
            Class.forName("org.apache.derby.jdbc.ClientDriver");  
            con=DriverManager.getConnection(  
            "jdbc:derby://localhost:1527/Apu Library Management System 2","Shamee","1234");  
            stmt=con.createStatement(); 
        }
        catch(Exception e)
        { 
            System.out.println(e);
            JOptionPane.showMessageDialog(this,"connection error");
        }
    }
    
    //connection close from the database
    public void disconnect()
    {
        try
        {
           con.close(); 
        }
        catch(Exception e)
        {}

    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Return.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Return.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Return.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Return.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Return().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField BookID;
    private javax.swing.JTextField BookName;
    private javax.swing.JTextField IssueDate;
    private javax.swing.JTextField ReturnDate;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField studentID;
    private javax.swing.JTextField studentName;
    // End of variables declaration//GEN-END:variables
}
