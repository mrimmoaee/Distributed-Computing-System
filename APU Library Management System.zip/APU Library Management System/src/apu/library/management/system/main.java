 
package apu.library.management.system;

import StudentClass.Book;
import StudentClass.Student;
import System.Interface;
import java.awt.List;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;


public class main extends javax.swing.JFrame {
  
    //Global Declaration
    DefaultTableModel dm;
    
    
    public main () throws RemoteException, NotBoundException {
        initComponents();      
        show_book();
        CreateColumns();
     
    }


    private void CreateColumns(){
        //get tablemodel
        dm= (DefaultTableModel)BookTable.getModel();
        
    }
    
    
    private void filter(String query){
        TableRowSorter<DefaultTableModel> tr= new  TableRowSorter<DefaultTableModel>(dm);
        BookTable.setRowSorter(tr);     
        tr.setRowFilter(RowFilter.regexFilter(query));
    }
 
    public void show_book() throws RemoteException, NotBoundException{
        
      try{
          
        Registry reg = LocateRegistry.getRegistry("127.0.0.1", 1054);
        Interface a = (Interface) reg.lookup("Server");
        ArrayList<Book> list = a.bookList();
        DefaultTableModel model= (DefaultTableModel)BookTable.getModel();
        Object[] row = new Object [6];
        for(int i=0; i<list.size(); i++){
            row[0]=list.get(i).getid();
            row[1]=list.get(i).getname();
            row[2]=list.get(i).getauthor();
            row[3]=list.get(i).getcategory();
            row[4]=list.get(i).getcourse();
            row[5]=list.get(i).getavailable();        
            model.addRow(row);
        }
                
      }
      catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
      }

    }   
    
    
    


    

    

    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btnReturn = new javax.swing.JButton();
        searchText = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        BookTable = new javax.swing.JTable();
        btnBorrow = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/GUI_Image/logout.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel3.setText("APU Library Management System");

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        btnReturn.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnReturn.setText("Return");
        btnReturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReturnActionPerformed(evt);
            }
        });
        jPanel1.add(btnReturn);
        btnReturn.setBounds(470, 290, 190, 31);

        searchText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchTextActionPerformed(evt);
            }
        });
        searchText.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchTextKeyReleased(evt);
            }
        });
        jPanel1.add(searchText);
        searchText.setBounds(330, 10, 330, 30);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("Search by ID:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(220, 10, 110, 22);

        BookTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book_ID", "BookName", "Author", "Category", "Course", "Available"
            }
        ));
        jScrollPane1.setViewportView(BookTable);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(30, 60, 790, 220);

        btnBorrow.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnBorrow.setText("Borrow");
        btnBorrow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrowActionPerformed(evt);
            }
        });
        jPanel1.add(btnBorrow);
        btnBorrow.setBounds(210, 290, 190, 31);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(255, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(186, 186, 186)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       
        Object[] options = {"Yes","No"};
        // OPTIONAL 
        int response=JOptionPane.showOptionDialog(null, "Are you sure to logout?","Log Out",JOptionPane.YES_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        if(response==0) {   
            this.setVisible(false);
            welc mf = new  welc();
            mf.setVisible(true);
        
        } else {                     
        }                  
      
       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void searchTextKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchTextKeyReleased
       String query =searchText.getText().toLowerCase();
       filter(query); //search the detail record of book
        
    }//GEN-LAST:event_searchTextKeyReleased

    private void searchTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchTextActionPerformed

    private void btnReturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReturnActionPerformed
          this.setVisible(false);
          Return f = new Return();
          f.setVisible(true);
    }//GEN-LAST:event_btnReturnActionPerformed

    private void btnBorrowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrowActionPerformed
        this.setVisible(false);
        Borrow mf = new Borrow();
        mf.setVisible(true);
    }//GEN-LAST:event_btnBorrowActionPerformed

    
    
    
    
   
    

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {            
           
                try {
                    new main().setVisible(true);
                } catch (RemoteException ex) {
                    Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NotBoundException ex) {
                    Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
                }                       
               
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable BookTable;
    private javax.swing.JButton btnBorrow;
    private javax.swing.JButton btnReturn;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField searchText;
    // End of variables declaration//GEN-END:variables
}
