
package apu.library.management.system;

import StudentClass.Book;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import static java.nio.file.Files.write;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author TP040804
 */
public class Borrow extends javax.swing.JFrame {

    //global variables
    Connection con;
    Statement stmt;
    ResultSet rs;
    String query;
    ResultSet rs1;
    String query1;

    Date date=new Date();
    SimpleDateFormat format=new SimpleDateFormat("dd-MM-yyyy");
    String  checkAvailability,Name,Mail,Intake;
    
    public Borrow() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        studentID = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        studentName = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        bookID = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        availabletxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        BookNametxt = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        issueDate = new javax.swing.JTextField();
        issueBtn = new javax.swing.JButton();
        Cancelbtn = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Issue Book");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel8.setText("APU Library Management System");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setLayout(null);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("APU Library Management System");
        jPanel2.add(jLabel9);
        jLabel9.setBounds(180, 10, 410, 40);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Student Id");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(180, 120, 65, 17);

        studentID.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        studentID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentIDActionPerformed(evt);
            }
        });
        studentID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                studentIDKeyReleased(evt);
            }
        });
        jPanel2.add(studentID);
        studentID.setBounds(280, 120, 260, 23);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Student Name");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(160, 150, 88, 17);

        studentName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        studentName.setEnabled(false);
        jPanel2.add(studentName);
        studentName.setBounds(280, 150, 261, 23);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Book Id");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(200, 180, 47, 17);

        bookID.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bookID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookIDActionPerformed(evt);
            }
        });
        bookID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                bookIDKeyReleased(evt);
            }
        });
        jPanel2.add(bookID);
        bookID.setBounds(280, 180, 260, 23);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Available");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(200, 210, 51, 17);

        availabletxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        availabletxt.setEnabled(false);
        jPanel2.add(availabletxt);
        availabletxt.setBounds(280, 210, 260, 23);

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Book name");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(180, 240, 69, 17);

        BookNametxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        BookNametxt.setEnabled(false);
        jPanel2.add(BookNametxt);
        BookNametxt.setBounds(280, 240, 261, 23);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Issue Date");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(190, 270, 64, 17);

        issueDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        issueDate.setEnabled(false);
        issueDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                issueDateActionPerformed(evt);
            }
        });
        jPanel2.add(issueDate);
        issueDate.setBounds(280, 270, 260, 23);

        issueBtn.setBackground(new java.awt.Color(204, 204, 204));
        issueBtn.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        issueBtn.setText("Issue");
        issueBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                issueBtnActionPerformed(evt);
            }
        });
        jPanel2.add(issueBtn);
        issueBtn.setBounds(250, 340, 63, 25);

        Cancelbtn.setBackground(new java.awt.Color(204, 204, 204));
        Cancelbtn.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Cancelbtn.setText("Cancel");
        Cancelbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelbtnActionPerformed(evt);
            }
        });
        jPanel2.add(Cancelbtn);
        Cancelbtn.setBounds(400, 340, 73, 25);

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Book Issue  information");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(270, 50, 230, 50);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 703, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void issueDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_issueDateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_issueDateActionPerformed

    private void bookIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bookIDActionPerformed

    private void bookIDKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bookIDKeyReleased
        try
        {
            //connect to the database
            connect();
            query="SELECT * FROM SHAMEE.BOOK WHERE BOOK_ID='"+ bookID.getText()+"'";
            rs=stmt.executeQuery(query);
            if(rs.next())
            {
                availabletxt.setText(rs.getString("available"));
                BookNametxt.setText(rs.getString("BOOKNAME"));
            }
            else
            {
                availabletxt.setText("");
                BookNametxt.setText("");
            }
            disconnect();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }//GEN-LAST:event_bookIDKeyReleased

    private void studentIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentIDActionPerformed

    private void studentIDKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_studentIDKeyReleased
        try
        {
            connect();
      
            query= "SELECT * FROM SHAMEE.STUDENT where ID='"+studentID.getText()+"'";
            rs=stmt.executeQuery(query);
            if(rs.next())
            {
                Name=rs.getString("name");
                Mail=rs.getString("Mail");
                Intake=rs.getString("Intake");
                studentName.setText(Name);
            }
            else
            studentName.setText("");
            disconnect();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        issueDate.setText(format.format(date));
    }//GEN-LAST:event_studentIDKeyReleased

    private void CancelbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelbtnActionPerformed
        this.setVisible(false);
        main mf;
        try {
            mf = new main();
            mf.setVisible(true);
        } catch (RemoteException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NotBoundException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        }
      
    }//GEN-LAST:event_CancelbtnActionPerformed

    private void issueBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_issueBtnActionPerformed
        if(studentName.getText().equals(""))
        JOptionPane.showMessageDialog(this,"This ID is not registered yet!"); //checking id is registered or not
        else
        {
            try
            {
                connect();
                query="SELECT * FROM SHAMEE.BOOK where BOOK_ID='"+ bookID.getText()+"'";
                rs=stmt.executeQuery(query);
                rs.next();
                if(availabletxt.getText().equals("YES"))
                {
                    query="INSERT into SHAMEE.ISSUE VALUES ('"+ studentID.getText()+"','"+ studentName.getText()+"','"+bookID.getText()+"','"+BookNametxt.getText()+"','"+issueDate.getText()+"','"+Mail+"','"+Intake+"')";
                    stmt.executeUpdate(query);
                    JOptionPane.showMessageDialog(this,"Book with id = "+ bookID.getText()+" has been issued to "+studentName.getText());
                    query="update SHAMEE.BOOK set Available='NO' where Book_Id='"+ bookID.getText()+"'"; //Change the availability of the book record
                    stmt.executeUpdate(query);

                }
                if(availabletxt.getText().equals("NO")) 
                {
                    JOptionPane.showMessageDialog(this,"Book with this id is not available currently");
                }
                if(availabletxt.getText().equals(""))
                {
                    JOptionPane.showMessageDialog(this,"There is no book in the library with this id");
                }

                    BookNametxt.setText("");
                    studentID.setText("");
                    studentName.setText("");
                    bookID.setText("");
                    availabletxt.setText("");
                    disconnect();

                }
                catch(SQLException e)
                {
                    if(e.getErrorCode()==1062)
                    JOptionPane.showMessageDialog(this,"A student can only get a single book from library at a time ");
                } 
            }
       
        //print report of borrow book
                
            List<String> data = new ArrayList<String>();
           
            try {   Class.forName("org.apache.derby.jdbc.ClientDriver");
                    java.sql.Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/Apu Library Management System 2","Shamee","1234");
                    Statement st = con.createStatement();
                 
                    String strp = "Borrow Book Detail,";        
                    data.add(strp);
                    ResultSet rs1 = st.executeQuery("SELECT * FROM SHAMEE.ISSUE");                   
                    while (rs1.next()) {
                          
                            String Student_id = rs1.getString("STUDENT_ID");
                            String Student_name = rs1.getString("STUDENT_NAME"); 
                            String Book_id = rs1.getString("BOOKID");  
                            String Book_name = rs1.getString("BOOKNAME");  
                            String issuedate = rs1.getString("ISSUEDATE");  
                            String mail = rs1.getString("MAIL"); 
                            String intake = rs1.getString("INTAKE");  
                            data.add("ID: " + Student_id + " , " + "StudentName: " + Student_name + " , " + "BookID: " + Book_id + " , " + "BookName: " + Book_name + " , " + "IssueDate: " + issuedate + " , " + "Mail: " + mail + " , " + "Intake: " + intake);
                            
                    }
                     
                    String str = "Remaining Book Detail,";         
                    data.add(str);
                    
                    ResultSet rs = st.executeQuery("SELECT * FROM SHAMEE.BOOK");                   
                    while (rs.next()) {
                          
                            String bookname = rs.getString("BOOKNAME");
                            String available = rs.getString("AVAILABLE");                        
                            data.add("BookName: " + bookname + " , " + "Available: " + available );
                            
                    }
                    writeToFile(data, "Report.txt");
                    
                    rs.close();
                    rs1.close();
                    st.close();
            } catch (Exception e) {
                    System.out.println(e);
            }
    }

    private static void writeToFile(java.util.List list, String path) {
            BufferedWriter out = null;
            try {
                    File file = new File(path);
                    out = new BufferedWriter(new FileWriter(file, true));
                    for (Object s : list) {
                            out.write((String) s);
                            out.newLine();
                         
                    }
                    
                    out.close();
                   
            } catch (IOException e) {
            }
    
        
        
        
        
        
        
       
    
    }//GEN-LAST:event_issueBtnActionPerformed

    //connection to the database
    public void connect()
    {
        try
        {  
            Class.forName("org.apache.derby.jdbc.ClientDriver");  
            con=DriverManager.getConnection(  
            "jdbc:derby://localhost:1527/Apu Library Management System 2","Shamee","1234");  
            stmt=con.createStatement(); 
        }
        catch(Exception e)
        { 
            System.out.println(e);
            JOptionPane.showMessageDialog(this,"connection error");
        }
    }
    
    //connection close from the database
    public void disconnect()
    {
        try
        {
           con.close(); 
        }
        catch(Exception e)
        {}

    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Borrow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Borrow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Borrow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Borrow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Borrow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField BookNametxt;
    private javax.swing.JButton Cancelbtn;
    private javax.swing.JTextField availabletxt;
    private javax.swing.JTextField bookID;
    private javax.swing.JButton issueBtn;
    private javax.swing.JTextField issueDate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField studentID;
    private javax.swing.JTextField studentName;
    // End of variables declaration//GEN-END:variables
}
